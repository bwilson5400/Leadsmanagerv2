# Wireless Sales Leads (v3)
Installable PWA with pipeline stages, daily summary notifications, and a built-in Sales Assistant.

## Deploy on GitHub Pages
1) Create a public repo, upload these files at the repo root.
2) Settings → Pages → Source: Deploy from a branch; Branch: main; Folder: /(root).
3) Visit https://YOUR-USERNAME.github.io/REPO-NAME/ in Safari (iPad/iPhone) → Share → Add to Home Screen.
4) In the app: tap Enable notifications, then Settings to set your daily summary time.

> iOS PWAs show local notifications while the app is open or in the background. For push when fully closed, wrap natively (APNs) or add a backend with Web Push (Android/desktop).
